# Install.ps1
param($installPath, $toolsPath, $package, $project)

$xml = New-Object xml

# find the App.config file
$config = $project.ProjectItems | where {$_.Name -eq "App.config"}

# find its path on the file system
$localPath = $config.Properties | where {$_.Name -eq "LocalPath"}

# load App.config as XML
$xml.Load($localPath.Value)

# select the node
$node = $xml.SelectSingleNode("//*/plugins/add[contains(@name,'Blackbaud.SpecFlow.Selenium.Blueshirt')]")

$pack = $package -replace " ","."
# change the path value
$node.SetAttribute("path", "..\packages\" + $pack)

# save the App.config file
$xml.Save($localPath.Value)