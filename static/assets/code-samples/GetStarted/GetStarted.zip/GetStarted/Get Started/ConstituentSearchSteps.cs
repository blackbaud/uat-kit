﻿using System;
using Blackbaud.UAT.Core.Crm;
using TechTalk.SpecFlow;

namespace Get_Started
{
    [Binding]
    public class ConstituentSearchSteps
    {
        [Given(@"I have logged into the BBCRM home page")]
        public void GivenIHaveLoggedIntoTheBBCRMHomePage()
        {
            BBCRMHomePage.Login();
        }

        [Given(@"I have opened the constituent search dialog")]
        public void GivenIHaveOpenedTheConstituentSearchDialog()
        {
            BBCRMHomePage.OpenConstituentsFA();
            ConstituentsFunctionalArea.OpenConstituentSearchDialog();
        }

        [When(@"I search for ""(.*)""")]
        public void WhenISearchFor(string name)
        {
            SearchDialog.SetLastNameToSearch(name);
            SearchDialog.Search();
        }

        [Then(@"The results should contain ""(.*)""")]
        public void ThenTheResultsShouldContain(string result)
        {
            SearchDialog.CheckConstituentSearchResultsContain(result);
        }
    }
}
