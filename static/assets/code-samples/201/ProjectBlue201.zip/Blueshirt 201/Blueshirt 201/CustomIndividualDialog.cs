﻿using System.Collections.Generic;
using Blueshirt.Core.Base;
using Blueshirt.Core.Crm;
using TechTalk.SpecFlow;

namespace Delving_Deeper
{
    public class CustomIndividualDialog : IndividualDialog
    {
        private static readonly IDictionary<string, CrmField> CustomSupportedFields = new Dictionary<string, CrmField>
        {
            {"Country of Origin", new CrmField("_ATTRIBUTECATEGORYVALUE0_value", FieldType.Dropdown)},
            {"Matriculation Year (Use)", new CrmField("_ATTRIBUTECATEGORYVALUE1_value", FieldType.Dropdown)}
        }; 

        public new static void SetIndividualFields(TableRow fields)
        {
            SetFields(GetDialogId(DialogIds), fields, SupportedFields, CustomSupportedFields);
        }

        public static void SetCustomField(string fieldCaption, string value)
        {
            SetField(GetDialogId(DialogIds), fieldCaption, value, CustomSupportedFields);
        }

        public new static void SetHouseholdFields(TableRow fields)
        {
            OpenTab("Household");
            if (fields.ContainsKey("Related individual"))
            {
                WaitClick(getXInputNewFormTrigger(getXInput(GetDialogId(DialogIds), "_SPOUSEID_value")));
                SetTextField(getXInput("IndividualSpouseBusinessSpouseForm", "_SPOUSE_LASTNAME_value"), fields["Related individual"]);
                OK();
                fields["Related individual"] = null;
                fields.Keys.Remove("Related individual");
            }
            IndividualDialog.SetHouseholdFields(fields);
        }
    }
}
