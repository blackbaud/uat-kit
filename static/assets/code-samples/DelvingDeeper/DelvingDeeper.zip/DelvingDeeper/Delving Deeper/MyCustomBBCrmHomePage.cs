﻿using System;
using Blackbaud.UAT.Core.Crm;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Delving_Deeper
{
    public class MyCustomBBCrmHomePage : BBCRMHomePage
    {
        public static void NavigateToFunctionalArea(string caption)
        {
            WebDriverWait navigateWaiter = new WebDriverWait(Driver, TimeSpan.FromSeconds(TimeoutSecs));
            navigateWaiter.IgnoreExceptionTypes(typeof(InvalidOperationException));
            navigateWaiter.Until(driver =>
            {
                IWebElement functionalAreaElement = driver.FindElement(By.XPath(String.Format("//button[text()='{0}']", caption)));
                if (!functionalAreaElement.Displayed) return false;
                functionalAreaElement.Click();
                return true;
            });
        }
    }
}
