﻿using System;
using Blackbaud.UAT.Base;
using Blackbaud.UAT.Core.Base;
using Blackbaud.UAT.Core.Crm;
using TechTalk.SpecFlow;

namespace Delving_Deeper
{
    [Binding]
    public class SampleTestsSteps : BaseSteps
    {
        [Given(@"I have logged into BBCRM and navigated to functional area ""(.*)""")]
        public void GivenIHaveLoggedIntoBbcrmAndNavigatedToFunctionalArea(string functionalArea)
        {
            BBCRMHomePage.Login();
            MyCustomBBCrmHomePage.NavigateToFunctionalArea(functionalArea);
        }

        [When(@"I navigate to functional area ""(.*)""")]
        public void WhenINavigateToFunctionalArea(string functionalArea)
        {
            MyCustomBBCrmHomePage.NavigateToFunctionalArea(functionalArea);
        }

        [Then(@"the panel header caption is ""(.*)""")]
        public void ThenThePanelHeaderCaptionIs(string headerCaption)
        {
            if (!BaseComponent.Exists(Panel.getXPanelHeaderByText(headerCaption))) 
                FailTest(String.Format("'{0}' was not in the header caption.", headerCaption));
        }

        [Given(@"I have logged into BBCRM")]
        public void GivenIHaveLoggedIntoBBCRM()
        {
            BBCRMHomePage.Login();
        }

        [When(@"I add constituent")]
        public void WhenIAddConstituent(Table constituents)
        {
            foreach (var constituent in constituents.Rows)
            {
                BBCRMHomePage.OpenConstituentsFA();
                constituent["Last name"] += uniqueStamp;
                ConstituentsFunctionalArea.AddAnIndividual(groupCaption: "Add Records");
                CustomIndividualDialog.SetIndividualFields(constituent);
                IndividualDialog.Save();
            }
        }

        [Then(@"a constituent is created")]
        public void ThenAConstituentIsCreated()
        {
            if (!BaseComponent.Exists(Panel.getXPanelHeader("individual"))) FailTest("A constituent panel did not load.");
        }

        [When(@"I start to add a constituent")]
        public void WhenIStartToAddAConstituent(Table constituents)
        {
            foreach (var constituent in constituents.Rows)
            {
                BBCRMHomePage.OpenConstituentsFA();
                constituent["Last name"] += uniqueStamp;
                ConstituentsFunctionalArea.AddAnIndividual();
                IndividualDialog.SetIndividualFields(constituent);
            }
        }

        [When(@"I set the custom constituent field ""(.*)"" to ""(.*)""")]
        public void WhenISetTheCustomConstituentFieldTo(string fieldCaption, string value)
        {
            CustomIndividualDialog.SetCustomField(fieldCaption, value);
        }

        [When(@"I save the add an individual dialog")]
        public void WhenISaveTheAddAnIndividualDialog()
        {
            IndividualDialog.Save();
        }

        [When(@"I open the constituent search dialog")]
        public void WhenIOpenTheConstituentSearchDialog()
        {
            BBCRMHomePage.OpenConstituentsFA();
            FunctionalArea.OpenLink("Searching", "Constituent search");
        }

        [When(@"set the Last/Org/Group name field value to ""(.*)""")]
        public void WhenSetTheLastOrgGroupNameFieldValueTo(string fieldValue)
        {
            SearchDialog.SetTextField(Dialog.getXInput("UniversityofOxfordConstituentSearch", "KEYNAME"), fieldValue);
        }

        [Then(@"the Last/Org/Group name field is ""(.*)""")]
        public void ThenTheLastOrgGroupNameFieldIs(string expectedValue)
        {
            SearchDialog.ElementValueIsSet(Dialog.getXInput("UniversityofOxfordConstituentSearch", "KEYNAME"), expectedValue);
        }

        [Given(@"a constituent exists")]
        public void GivenAConstituentExists(Table constituents)
        {
            foreach (var constituent in constituents.Rows)
            {
                BBCRMHomePage.OpenConstituentsFA();
                constituent["Last name"] += uniqueStamp;
                ConstituentsFunctionalArea.AddAnIndividual(constituent);
            }
        }

        [When(@"set the household fields")]
        public void WhenSetTheHouseholdFields(Table fieldsTable)
        {
            foreach (var fieldValues in fieldsTable.Rows)
            {
                CustomIndividualDialog.SetHouseholdFields(fieldValues);
            }
        }

        [Given(@"a constituent exists with last name ""(.*)""")]
        public void GivenAConstituentExistsWithLastName(string constituent)
        {
            constituent += uniqueStamp;
            BBCRMHomePage.OpenConstituentsFA();
            ConstituentsFunctionalArea.AddAnIndividual();
            IndividualDialog.SetLastName(constituent);
            IndividualDialog.Save();
        }

        [When(@"I add an address to the current constituent")]
        public void WhenIAddAnAddressToTheCurrentConstituent(Table addressTable)
        {
            foreach (TableRow row in addressTable.Rows)
            {
                ConstituentPanel.SelectTab("Contact");
                ConstituentPanel.ClickSectionAddButton("Addresses");
                if (row.ContainsKey("Country") && string.IsNullOrEmpty(row["Country"])) row["Country"] = null;
                AddressDialog.SetAddressFields(row);
                Dialog.Save();
            }
        }

        [Then(@"an address exists")]
        public void ThenAnAddressExists(Table addressTable)
        {
            ConstituentPanel.SelectTab("Contact");
            foreach (TableRow row in addressTable.Rows)
            {
                if (!ConstituentPanel.SectionDatalistRowExists(row, "Addresses"))
                    FailTest(String.Format("Address '{0}' not found.", row.Values));
            }
        }

        [Given(@"I add an address to the current constiteunt")]
        public void GivenIAddAnAddressToTheCurrentConstiteunt(Table addressTable)
        {
            WhenIAddAnAddressToTheCurrentConstituent(addressTable);
        }

        [When(@"I start to edit an address on the current constituent")]
        public void WhenIStartToEditAnAddressOnTheCurrentConstituent(Table addressTable)
        {
            ConstituentPanel.SelectTab("Contact");
            ConstituentPanel.SelectSectionDatalistRow(addressTable.Rows[0], "Addresses");
            ConstituentPanel.WaitClick(ConstituentPanel.getXSelectedDatalistRowButton("Edit"));
        }

        [When(@"set the address fields and save the dialog")]
        public void WhenSetTheAddressFields(Table addressTable)
        {
            AddressDialog.SetAddressFields(addressTable.Rows[0]);
            Dialog.Save();
        }


    }
}
